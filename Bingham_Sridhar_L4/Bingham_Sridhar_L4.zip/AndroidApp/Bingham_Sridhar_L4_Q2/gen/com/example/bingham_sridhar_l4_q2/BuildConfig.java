/** Automatically generated file. DO NOT MODIFY */
package com.example.bingham_sridhar_l4_q2;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}