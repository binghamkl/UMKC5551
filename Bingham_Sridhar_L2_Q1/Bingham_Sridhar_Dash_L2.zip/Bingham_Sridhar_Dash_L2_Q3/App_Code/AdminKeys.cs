﻿#region -- using declarations --

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

#endregion

/// <summary>
/// Summary description for AdminKeys
/// </summary>
struct AdminKeys
{

    public String UserName;
    public String Password;

	
}